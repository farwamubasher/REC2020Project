# REC2020
Programming Category
Group Name: Team Dogs

Project Name: Netflux Recommendation Search Engine

Group Member Names  |    Emails

Farwa Mubasher      |    farwa.mubasher@ryerson.ca

Isha Cheema         |    isha.cheema@ryerson.ca

Mohammad Zaman      |    mohammad.s.zaman@ryerson.ca

Adnan Hossain       |    adnan.hossain@ryerson.ca
 
All the code needed for this project is located in the main.py file. For the judges to run the code they just have to run it in a Python Compiler. It has all the instructions to get your recommeded list. The user has to choose one input to sort and obtain a recommended list based on the rating of the movie. 

Install pandas library and have Python 3.8 installed. Python compiler will be needed. Inputs will be done through compiler terminal.
